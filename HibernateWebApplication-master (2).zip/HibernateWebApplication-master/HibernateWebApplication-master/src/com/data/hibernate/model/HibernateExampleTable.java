/**
 * 
 */
package com.data.hibernate.model;

/**
 * @author 172730
 *
 */
public class HibernateExampleTable {

	
	private int id;
	private String name;
	private String email;
	private int  mobNumber;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	/**
	 * @return the mobNumber
	 */
	public int getMobNumber() {
		return mobNumber;
	}
	/**
	 * @param mobNumber the mobNumber to set
	 */
	public void setMobNumber(int mobNumber) {
		this.mobNumber = mobNumber;
	}
	@Override
	public String toString() {
		return "HibernateExampleTable [id=" + id + ", name=" + name + ", email=" + email + ", mobNumber=" + mobNumber
				+ "]";
	}
	
	
	
	
}
