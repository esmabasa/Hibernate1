package com.data.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.data.hibernate.model.HibernateExampleTable;

/**
 * @author 172730
 *
 */
public class HibernateExampleDAO {

	public static Integer addDetails(HibernateExampleTable hbTable) {
		Integer rowAffected = 0;
		System.out.println("  Hibernate program execution begins");
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("com/data/hibernate/dao/hibernate.cfg.xml").build();
		Metadata mData = new MetadataSources(ssr).getMetadataBuilder().build(); // getting Outline of database and table mapping from configuration file
		
		SessionFactory sessFactory = mData.getSessionFactoryBuilder().build(); // Getting session factory object
		Session session = sessFactory.openSession(); // getting session for DB operation from session factory
		Transaction tx = session.beginTransaction(); // Before doing data base operation creating transaction object
		try {
		rowAffected = (int) session.save(hbTable);
		tx.commit();
		System.out.println("  return value after saving data  ::  "+rowAffected);
		return rowAffected;
		} catch (HibernateException hibernateEx) {
			 
				System.err.printf("Information Not Found", hibernateEx);				
			}
		
		if(session != null) {
			session.close();	
					}
		return rowAffected;

	}
}
